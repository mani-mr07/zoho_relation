package com.mail.logic;

import java.sql.ResultSet;

import com.mail.db.dao.MailDAO;

public class DashBoard {
	static ResultSet rs = null;
	public static ResultSet identifyNprocess(String sender, String feild, String key) {
		MailDAO MailDAO = new MailDAO(); 
		try {
			switch(feild) {
				case "receivers":
					return MailDAO.getMailByReceiver(sender, key);
				
				case "subject":
					return MailDAO.getMailBySubject(sender, key);
				
				case "content":
					return MailDAO.getMailByContent(sender, key);
				
				default:
					return MailDAO.getUserMails(sender);
			}
		}catch (Exception e) {
			e.printStackTrace();
			return rs;
		}
	}

}
