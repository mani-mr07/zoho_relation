package com.mail.logic;

import java.io.FileInputStream;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class SendMail{
	private static Properties properties;
	//sending mail
	public static boolean mail(String sender, String[] receiver, String subject, String content) {
		Message message = prepareMessage(getSession(), sender, receiver, subject, content);
		try {
            Transport.send(message);
            System.out.println("Email sent successfully.");
        } catch (MessagingException e) {
            System.out.println("Error while sending the message");
            e.printStackTrace();
            return false;
        }
		return true;
	}
	
	// get ready properties
	public static Properties getProperties() {
        if (properties == null) {
            try {
                FileInputStream fis = new FileInputStream("/Users/sri-22685/software-workspace/eclipse-workspace/DBExtension_Completed2/src/main/resources/mailconf.properties");
                properties = new Properties();
                properties.load(fis);
            } catch (Exception e) {
                System.out.println("Configuration Error");
                e.printStackTrace();
            }
        }
        return properties;
    }
	
	// prepare session
	public static Session getSession() {
		getProperties();
		String sender = properties.getProperty("mail.sender");
		String senderCode = properties.getProperty("mail.passcode");
		Session session = Session.getInstance(SendMail.getProperties(), new Authenticator() {
			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new javax.mail.PasswordAuthentication(sender, senderCode);
			}
		});
		return session;
	}
	
	// prepare message
	public static Message prepareMessage(Session session, String sender, String[] receivers, String subject, String content) {
        Message msg = null;
        try {
            msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(sender));
            
            Address[] reciversAddress = new InternetAddress[receivers.length];
            for(int i=0; i<receivers.length ;i++) {
            	reciversAddress[i] = new InternetAddress(receivers[i]);
            }
            
            msg.addRecipients(Message.RecipientType.TO, reciversAddress);
            msg.setSubject(subject);
            msg.setText(content);
        } catch (Exception e) {
            System.out.println("Error while preparing message...");
            e.printStackTrace();
        }
        return msg;
    }
	
	// separate receivers
	public static String[] seperateRecivers(String receivers) {
    	String recivers[] = receivers.split(",");
    	for(int i=0; i<recivers.length ;i++){
    		recivers[i] = recivers[i].trim();
    	}
    	return recivers;
    }
}
