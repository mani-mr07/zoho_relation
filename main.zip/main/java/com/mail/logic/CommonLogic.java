package com.mail.logic;

import java.util.Random;

public class CommonLogic {
	
//  Random Number Logic
	public static int generateOTP(){
        int i=0;
        int res = generateRandomNumber();
        
        while(i<4){
        	res = res*10 + generateRandomNumber();
        	i++;
        }
        return res;
    }
    
    public static int generateRandomNumber(){
        Random rand = new Random();
        int n = rand.nextInt(10);
        return n;
    }
}
