package com.mail.db.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DAO {
	private static String uri;
	private static String rootUser;
	private static String rootPassword;
	private static String driverClass;
	private Connection connection;
	private Statement statement;
	
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public Statement getStatement() {
		return statement;
	}

	public void setStatement(Statement statement) {
		this.statement = statement;
	}

	public DAO() {
		try {
			FileInputStream fis = new FileInputStream("/Users/sri-22685/software-workspace/eclipse-workspace/DBExtension_Completed2/src/main/resources/auth.properties");
			Properties properties = new Properties();
			properties.load(fis);
			
			uri = properties.getProperty("db.uri");
			rootUser = properties.getProperty("db.rootUser");
			rootPassword = properties.getProperty("db.rootPassword");
			driverClass = properties.getProperty("db.driverClass");
			
			Class.forName(driverClass);
			if(connection == null) {
				connection = DriverManager.getConnection(uri, rootUser, rootPassword);
			}
			
			statement = connection.createStatement();
		} catch (ClassNotFoundException | SQLException | IOException e) {
			System.out.println("Connection Error!");
			e.printStackTrace();
		}
	}	
	 
}


/*
srp
sriramprasath07@gmail.com
123
*/