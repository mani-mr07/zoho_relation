package com.mail.db.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	private static final String USER_TABLE = "userInfo";
	private static final String Auth_TABLE = "editAuth";
	private String query;
	private DAO DAO;
	
	public UserDAO(){
		DAO = new DAO();
	}
	
	public DAO getDAO() {
		return DAO;
	}

	// Check User Availability in DB
	boolean userExists(String userMail, String table) {
		query = "SELECT * FROM "+table+" WHERE userMail = '"+userMail+"'"; 
		try {
			ResultSet rs = DAO.getStatement().executeQuery(query);
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("User not exists");
			e.printStackTrace();
		}
		return false;
	}
	
	// Login Validation
	public boolean validateLogin(String userMail, String password){
		String query = "SELECT * FROM userInfo WHERE userMail = '"+userMail+"'";
		try {
			ResultSet rs = DAO.getStatement().executeQuery(query);
			
			if(rs.next()) {
				String validUserID = rs.getString(3);
				String validPass = rs.getString(4);
				
				return validUserID.equals(userMail) && validPass.equals(password);
			}
		} catch (Exception e) {
			System.out.println("Validation Failed");
			e.printStackTrace();
		}
		
		return false;
	}
	
	//	User Registration
	public int registerUser(String userName, String userMail, String password) {
		if(!userExists(userMail, USER_TABLE)) {
			try {
				query = "INSERT INTO userInfo (userName, userMail, userPass) VALUES (?,?,?)";
				PreparedStatement pst =  DAO.getConnection().prepareStatement(query);
				pst.setString(1, userName);
				pst.setString(2, userMail);
				pst.setString(3, password);
	
				int i = pst.executeUpdate();
				return i!=0? 1: 0;
			}catch (Exception e) {
				System.out.println("Registration Failed!");
				e.printStackTrace();
			}
		} else {
			return -1;
		}
		return 0;
	}
	
	int getUserID(String userMail) {
		int id = -1;
		query = "SELECT * FROM userInfo WHERE userMail = '"+userMail+"'";
		try {
			ResultSet rs = DAO.getStatement().executeQuery(query);
			if(rs.next()) {
				return  rs.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println("User Not Exists!!");
			e.printStackTrace();
		} 
		
		return id;
	}
	
	public boolean resetPassword(String mail, String password){
		query = "UPDATE userInfo SET userPass = '"+password+"' WHERE userMail = '"+mail+"'";
		
		try {
			PreparedStatement pst = DAO.getConnection().prepareStatement(query);
			int i =pst.executeUpdate();
			return i!=0? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// verify the sendOTP from DB
	public boolean verifyOTP(String userMail, int otp) {
		query = "SELECT * FROM editAuth WHERE userMail = '"+userMail+"'";
		
		try {
			ResultSet rs = DAO.getStatement().executeQuery(query);
			if(rs.next()) {
				String cMail = rs.getString(1);
				int vOTP = rs.getInt(2);
				if(cMail.equals(userMail) && vOTP==otp) {
					return true;
				}
			}
		} catch (SQLException e) {
			System.out.println("OTP INVALID");
			e.printStackTrace();
		}
		return false;
	}

	// Register the SendOTP in DB
	public boolean registerOTP(String mail, int otp) {
		if(userExists(mail, USER_TABLE)) {
			if(!userExists(mail, Auth_TABLE)) {
				query = "INSERT INTO "+Auth_TABLE+" VALUES (?,?)";
				try {
					PreparedStatement pst = DAO.getConnection().prepareStatement(query);
					pst.setString(1, mail);
					pst.setInt(2, otp);
					
					pst.executeUpdate();
					System.out.println("OTP SET SUCCESS!");
					return  true;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				query = "UPDATE "+Auth_TABLE+" SET otp = '"+otp+"' WHERE userMail = '"+mail+"'";
				try {
					PreparedStatement pst = DAO.getConnection().prepareStatement(query);
					pst.executeUpdate();
					System.out.println("OTP UPDATE SUCCESS!");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("OTP: "+otp+"\n Mail : "+mail);
				return  true;
			}
		} else {
			System.out.println("Mail Doesnot exist!");
		}
		return false;
	}
	
	

}
