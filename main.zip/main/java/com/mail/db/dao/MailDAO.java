package com.mail.db.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MailDAO {
		private static DAO DAO;
		
	    public boolean storeMailDetails(String sender, String receivers, String subject, String content, String dateTime){
	    	String query = "INSERT INTO mailDB (sender, receivers, sub, content, dateTime) VALUES (?, ?, ?, ?, ?)";
	    	DAO = new DAO();
	    	
	    	try {
				PreparedStatement ps = DAO.getConnection().prepareStatement(query);
				ps.setString(1, sender);
				ps.setString(2, receivers);
				ps.setString(3, subject);
				ps.setString(4, content);
				ps.setString(5, dateTime);
				
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
	    	
	    	return true;
	    }
	    
	    public ResultSet getMailBySubject(String sender, String subject) { 
	    	ResultSet rs = null;
	    	String query = "SELECT * FROM mailDB WHERE sender = '"+sender+"' AND (sub LIKE '%"+subject.toLowerCase()+"%' OR sub LIKE '%"+subject.toUpperCase()+"%')";
	    	DAO = new DAO();
	    	try {
				PreparedStatement ps = DAO.getConnection().prepareStatement(query);
				rs = ps.executeQuery();
	    	} catch (SQLException e) {
				e.printStackTrace();
				return rs;
			}
	    	return rs;
	    }
	    
	    public ResultSet getMailByReceiver(String sender, String receiver) { 
	    	ResultSet rs = null;
	    	String query = "SELECT * FROM mailDB WHERE sender = '"+sender+"' AND (receivers LIKE '%"+receiver.toLowerCase()+"%' OR receiver LIKE '%"+receiver.toUpperCase()+"%')";
	    	DAO = new DAO();
	    	try {
				PreparedStatement ps = DAO.getConnection().prepareStatement(query);
				rs = ps.executeQuery();
	    	} catch (SQLException e) {
				e.printStackTrace();
				return rs;
			}
	    	return rs;
	    }
	    
	    public ResultSet getMailByContent(String sender, String content) { 
	    	ResultSet rs = null;
	    	String query = "SELECT * FROM mailDB WHERE sender = '"+sender+"' AND (content LIKE '%"+content.toLowerCase()+"%' OR content LIKE '%"+content.toUpperCase()+"%')";
	    	DAO = new DAO();
	    	try {
				PreparedStatement ps = DAO.getConnection().prepareStatement(query);
				rs = ps.executeQuery();
	    	} catch (SQLException e) {
				e.printStackTrace();
				return rs;
			}
	    	return rs;
	    }
	    
	    
	    public ResultSet getUserMails(String sender) {
	    	ResultSet rs = null;
	    	String query = "SELECT * FROM mailDB WHERE sender = '"+sender+"'";;
			
	    	DAO = new DAO();
	    	try {
				PreparedStatement ps = DAO.getConnection().prepareStatement(query);
				rs = ps.executeQuery();
	    	} catch (SQLException e) {
				e.printStackTrace();
				return rs;
			}
	    	return rs;
	    }
	    
	    
 	    
}
