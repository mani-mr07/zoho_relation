package com.mail.db.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DashBoardDAO {
	DAO DAO;
	public DashBoardDAO() {
		this.DAO = new DAO();
	}

	public ResultSet fetchAllUserSendMails(String mail) {
	    	String query = "SELECT * FROM mailDB WHERE sender = '"+mail+"'";
	    	ResultSet rs = null;
	    	try {
	    		PreparedStatement ps = DAO.getConnection().prepareStatement(query);
	    		rs = ps.executeQuery();
	    	} catch (Exception e) {
	    		e.printStackTrace();
	    	}
	    	return rs;
	    }
    
    public ResultSet fetchSpecificMail(int mailId) {
    	String query = "SELECT * FROM mailDB WHERE mailId = '"+mailId+"'";
	    	ResultSet rs = null;
	    	try {
	    		PreparedStatement ps = DAO.getConnection().prepareStatement(query);
	    		rs = ps.executeQuery();
	    	} catch (Exception e) {
	    		e.printStackTrace();
	    	}
	    	return rs;
    }
}
