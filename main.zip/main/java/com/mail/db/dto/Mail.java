package com.mail.db.dto;

public class Mail {
	private int msgId;
	private int sendId;
	private String sender;
	private String reciver;
	private String subject;
	private String content;
	
	public Mail(String sender, String subject, String content) {
		super();
		this.sender = sender;
		this.subject = subject;
		this.content = content;
	}

	public int getMsgId() {
		return msgId;
	}

	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

	public int getSendId() {
		return sendId;
	}

	public void setSendId(int sendId) {
		this.sendId = sendId;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReciver() {
		return reciver;
	}
	
	public void setReciver(String reciver) {
		this.reciver = reciver;
	}
	
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
}
