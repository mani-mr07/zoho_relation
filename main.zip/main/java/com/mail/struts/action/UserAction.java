package com.mail.struts.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.mail.db.dao.MailDAO;
import com.mail.db.dao.UserDAO;
import com.mail.logic.CommonLogic;
import com.mail.logic.SendMail;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport implements ServletRequestAware, SessionAware{
	private static final long serialVersionUID = 1L;
	// input names
	private static final String _USER_MAIL = "userMail";
	private static final String _USER_NAME = "userName";
	private static final String _USER_PASSWORD = "pass";
	
	private HttpServletRequest request;
	private Map<String, Object> session;
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public String registerUserStatus() throws Exception {
		String res = SUCCESS;

		String userMail = request.getParameter(_USER_MAIL);
		String password = request.getParameter(_USER_PASSWORD);
		String userName = request.getParameter(_USER_NAME);
		
		UserDAO UserDAO = new UserDAO();
		int data = UserDAO.registerUser(userName, userMail, password);
		if(data == 0){
			res = "failure";
		} else if (data < 0) {
			request.getSession().setAttribute("errorMsg", "User Already Exists!");
			res = "exist";
		} 
		
		return res;
	}
	
	public String loginValidationStatus() {
		String res = SUCCESS;
		
		String userMail = request.getParameter(_USER_MAIL);
		String password = request.getParameter(_USER_PASSWORD);
		UserDAO UserDAO = new UserDAO();
		if(!UserDAO.validateLogin(userMail,password)) {
			session.put("errorMsg", "Invalid Login credentials!");
			res = "failure";
		} else {
//			Fetching all userMails
			MailDAO MailDAO = new MailDAO();
			session.put("set", MailDAO.getUserMails(userMail));
			
			session.put("sender", userMail);
			session.put("isLogedin", 1);
		}
		return res;
	}
	
	public String generateOTPStatus() {
		String res = "success";
		String sender = "noreply.xyz@xyz.com";
		String subject = "OTP - Reset Password";
		String content = "OTP = ";
		String receiver[] = new String[1];
		receiver[0] = request.getParameter("userMail");
		
		int otp = CommonLogic.generateOTP();
		SendMail.mail(sender, receiver, subject, content+otp);
		UserDAO UserDAO = new UserDAO();
		if(!UserDAO.registerOTP(receiver[0], otp)) {
			res = "failure";
		}
		
		return res;
	}
	
	public String verifyOTPStatus() {
		String res = "success";
		
		String userMail = request.getParameter("to");
		session.put("userMail", userMail);
		int otp = Integer.parseInt(request.getParameter("otp"));
		UserDAO UserDAO = new UserDAO();
		if(!UserDAO.verifyOTP(userMail, otp)) {
			res = "failure";
		}
		return res;
	}
	
	public String resetPasswordStatus(){
		String res = "success";
		Object isLogedin = session.get("isLogedin");
		if(isLogedin == null) {
			return  "redirectlogin";
		}
		
		UserDAO UserDAO = new UserDAO();
		String userMail = (String) session.get("userMail");
		String newPass = (String) request.getParameter("pass");
		if(!UserDAO.resetPassword(userMail, newPass)) {
			res = "failure";
		} else if (isLogedin != null) {
			res = "logedin";
		} 
		
		return res;
	}
	
}
