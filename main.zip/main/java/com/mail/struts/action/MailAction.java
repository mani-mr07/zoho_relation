package com.mail.struts.action;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.mail.db.dao.MailDAO;
import com.mail.logic.SendMail;
import com.opensymphony.xwork2.ActionSupport;

public class MailAction extends ActionSupport implements ServletRequestAware, SessionAware{
	private static final long serialVersionUID = 1L;
	private static final String _SENDER = "sender";
	private static final String _RECIVER = "to";
	private static final String _SUBJECT = "subject";
	private static final String _CONTENT = "cont";
	private HttpServletRequest request;
	private Map<String, Object> session;
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public String sendMail(){
		String res="send";
    	String recivers = request.getParameter(_RECIVER);
    	String subject = request.getParameter(_SUBJECT);
    	String content = request.getParameter(_CONTENT);
    	String sender = (String) session.get(_SENDER);
    	
    	String[] receiver = SendMail.seperateRecivers(recivers);
//    	---> sender could be null if you directly use mail page so handle it
    	MailDAO MailDAO = new MailDAO();
    	LocalDateTime dateTime = LocalDateTime.now();
    	DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss");
    	String formated = dateTime.format(dateTimeFormat);
    	if(!MailDAO.storeMailDetails(sender, recivers, subject, content, formated) || !SendMail.mail(sender, receiver, subject, content)) {
    		res = "notsend";
    	} 
   	
    	return res;
	}
	
}
