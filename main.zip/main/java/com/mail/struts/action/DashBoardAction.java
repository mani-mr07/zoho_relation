package com.mail.struts.action;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.mail.db.dao.DashBoardDAO;
import com.mail.logic.DashBoard;

public class DashBoardAction implements SessionAware,  ServletRequestAware{
	Map<String, Object> session;
	HttpServletRequest request;
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public String filterMail() {
		String sender = (String) session.get("sender");
		String filed = request.getParameter("filed");
		String key = request.getParameter("key");
		ResultSet set = DashBoard.identifyNprocess(sender, filed, key);
		session.put("set", set);
		return "success";
	}
	
	public String mailDetails() {
		String res = "success";
		DashBoardDAO DashBoardDAO = new DashBoardDAO();
		int mailId = Integer.parseInt(request.getParameter("id"));
		
		ResultSet rs = DashBoardDAO.fetchSpecificMail(mailId);
		try {
			if(!rs.next()) {
				res = "failure";
			} else {
				String receiver = rs.getString("receivers");
				String subject = rs.getString("sub");
				String content = rs.getString("content");
				String dateTime = rs.getString("dateTime");
				
				session.put("mailId", mailId);
				session.put("receiver", receiver);
				session.put("subject", subject);
				session.put("content", content);
				session.put("dateTime", dateTime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	
	public String mailForward() {
		String res = "success";
		DashBoardDAO DashBoardDAO = new DashBoardDAO();
		int mailId = (int) session.get("mailId");
		ResultSet rs = DashBoardDAO.fetchSpecificMail(mailId);
		try {
			if(!rs.next()) {
				res = "failure";
			} else {
				String receiver = rs.getString("receiver");
				String subject = rs.getString("sub");
				String content = rs.getString("content");
				
				subject += "-----forward message-------";
				content = "from:"+session.get("sender")+", to:"+receiver+"\n"+content;
				session.put("subject", subject);
				session.put("content", content);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
}
